function filterByYear (obj, yyyy) {
    var filterObj = require('filter-obj');
    
    filteredList = filterObj(obj, function(key, value, object){
        return value === yyyy;
        console.log(filteredList);
        
    });                        
};


list = [{
	date: "07-09-07",
	amount: "6789",
	description: ""
}, {
	date: "07-08-07",
	amount: "678",
	description: ""
}, {
	date: "07-07-07",
	amount: "90",
	description: ""
}];



function appendTimes (obj) {
    $.each(obj, function () {
        this.date= new Date(this.date);
        var actualDate=this.date;
        var actualYear = actualDate.getFullYear();
        //alert (actualYear);
        $(this).year = actualYear;
        alert(obj.year);
    
       
        /*//alert(actualYear);
        //Jan 1st of the year:
        var startDate = new Date("01-01-"+actualYear.toString());
        //difference in seconds:
        var diff = (actualDate-startDate)/1000;
        var secondsPerWeek = (60*60*24*7);
        var weekNo = Math.ceil(diff/(secondsPerWeek));*/
        
        });
    console.log(obj);
    };

appendTimes(list);


______________________________


another way:
function appendTimes (obj) {
  var i, len, actualDate, actualYear;
  for (i = 0, len = obj.length; i < len; i++) {
    obj[i].date = new Date(obj[i].date);
    actualDate=obj[i].date;
    actualYear = actualDate.getFullYear();
    obj[i].year = actualYear;

  };
	console.log(obj);  
  };

appendTimes(list);